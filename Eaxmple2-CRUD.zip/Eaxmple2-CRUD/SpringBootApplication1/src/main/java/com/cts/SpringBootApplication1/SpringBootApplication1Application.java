package com.cts.SpringBootApplication1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootApplication1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootApplication1Application.class, args);
	}

}

package com.cts.SpringBootApplication1;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.rest.model.Employee;

@RestController
public class EmployeeServiceController {
   
	static Map<String,Object> emMap=new HashMap<>();
	static{
		Employee employee1=new Employee();
		employee1.setId("1");
		employee1.setName("James");
		
		Employee employee2=new Employee();
		employee2.setId("2");
		employee2.setName("Johnson");
		
		emMap.put(employee1.getId(), employee1);
		emMap.put(employee2.getId(), employee2);
	}
	
	//GET Operation
	@RequestMapping(value="/employees",method=RequestMethod.GET)
	public ResponseEntity<Object> getEmployee(){
		return new ResponseEntity<>(emMap.values(),HttpStatus.OK);
		
	}
	
	//POST
	@RequestMapping(value="/employees",method=RequestMethod.POST)
	public ResponseEntity<Object> createEmployee(@RequestBody Employee employee){
		emMap.put(employee.getId(), employee);
		return new ResponseEntity<>("Employee has been successfully created",HttpStatus.CREATED);
	}
	
	//PUT
	@RequestMapping(value="/employees/{id}",method=RequestMethod.PUT)
   public ResponseEntity<Object> editEmployee(@PathVariable("id") String id,@RequestBody Employee employee){
		emMap.remove(id);
		employee.setId("4");
		emMap.put(employee.getId(), employee);
		return new ResponseEntity<>("Employee has been successfully updated",HttpStatus.OK);
	}
	
	//DELETE
	@RequestMapping(value="/employees/{id}",method=RequestMethod.DELETE)
	public ResponseEntity<Object> editEmployee(@PathVariable("id") String id){
		emMap.remove(id);
		return new ResponseEntity<>("Employee has been successfully deleted",HttpStatus.OK);
	}
	
}





